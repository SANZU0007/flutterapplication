import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';
import 'package:testapp/colors.dart';

class DashboardCard extends StatelessWidget {
  final String value2;
  final String displayLabel;

  const DashboardCard({
    Key? key,
    required this.value2,
    required this.displayLabel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Parse the value to ensure it's a valid number
    double currentValue2 = double.tryParse(value2) ?? 0.0;

    // Ensure the value is within the range of 0 to 100
    currentValue2 = currentValue2.clamp(0.0, 100.0);

    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // Label for value2
            Text(
              "Value 2: $value2",
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 16),
            // Circular Pie Chart Gauge for Value 2
            Tooltip(
              message: '${currentValue2.toStringAsFixed(2)}%',
              child: SfRadialGauge(
                axes: <RadialAxis>[
                  RadialAxis(
                    minimum: 0,
                    maximum: 100,
                    startAngle: 270, // Start from the bottom (270 degrees)
                    endAngle: 630, // Full 360 degrees (opposite side)
                    radiusFactor: 0.75, // Size of the gauge
                    showTicks: false,
                    showLabels: false,
                    axisLineStyle: AxisLineStyle(
                      thickness: 0.99,
                      color: Colors.grey
                          .withOpacity(0.3), // Background circle color
                      thicknessUnit: GaugeSizeUnit.factor,
                    ),
                    pointers: <GaugePointer>[
                      // Full circle that fills up
                      RangePointer(
                        value: currentValue2,
                        color: Colors.orange, // Full circle color
                        width: 0.99,
                        sizeUnit: GaugeSizeUnit.factor,
                      ),
                    ],
                    annotations: <GaugeAnnotation>[
                      GaugeAnnotation(
                        widget: Center(
                          child: Text(
                            '${displayLabel}',
                            style: const TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        angle: 270, // Start from the bottom for annotation
                        positionFactor: 0.5,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
