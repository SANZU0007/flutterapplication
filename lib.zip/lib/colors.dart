import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFFD6762F); // Example orange color

const Color primaryColorbg = Color(0xFFEDEDED); // Example purple color

const Color primaryColorblue = Color(0xFF00D6FF); // Example purple color

const Color transparentWhite = Color(0xEAD9D6D6); // Example purple color
