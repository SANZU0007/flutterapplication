const String appName = 'Welcome to login';
const String slogan = 'E-senz ';

const String foodimage = 'assets/foodapp.jpg';

const String companyLogo = 'assets/esenzlogo.png';

const String login = 'Login';
